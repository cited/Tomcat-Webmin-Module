Authors
-------
* `David Ghedini`_
* `Kaloyan Petrov`_
* `Cited, Inc`_

.. _`David Ghedini`: https://github.com/DavidGhedini
.. _`Kaloyan Petrov`: https://github.com/kaloyan13
.. _`Cited, Inc`: https://www.citedcorp.com

