============
Installation
============

The preferred method is installing via GIT.

Install the package with GIT::

    $ git clone https://github.com/cited/Tomcat-Webmin-Module

    $ mv Tomcat-Webmin-Module tomcat

    $ tar -cvzf tomcat.wbm.gz tomcat/
    
    
Upload from Webmin->Webmin Configuration->Webmin Modules

Go to Servers->Apache Tomcat (you may need to refresh page)
